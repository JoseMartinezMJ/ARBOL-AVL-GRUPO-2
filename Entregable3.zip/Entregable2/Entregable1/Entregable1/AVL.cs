﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entregable2
{
    public class AVL
    {
        #region Propiedades

        public Nodo root;
        public Nodo aux;
        private string inordenA;
        private string preordenA;
        private string postordenA;

        #endregion

        public AVL()
        {
            aux = new Nodo();
        }

        public AVL(Nodo r)
        {
            root = r;
        }

        public void insertar(int fact)
        {
            if (root == null)
            {
                root = new Nodo(fact, null, null, null);
            }
            else
            {
                root = root.insertar(fact, root);
            }
        }
        #region Recorridos
        public string order(int d)
        {
            string tem = "";
            if (d == 1)
            {
                tem = preorden();
            }
            if (d == 2)
            {
                tem = inorden();
            }
            if (d == 3)
            {
                tem = postorden();
            }
            return tem;
        }

        public string inorden()
        {
            inordenA = "";
            if (root != null)
            {
                inorden2(root);
            }
            return inordenA;

        }

        private void inorden2(Nodo p)
        {
            if (p != null)
            {
                inorden2(p.left);
                inordenA += p.fact.ToString() + ",";
                inorden2(p.right);
            }
        }

        public string preorden()
        {
            preordenA = "";
            if (root != null)
            {
                preorden2(root);
            }
            return preordenA;
        }

        private void preorden2(Nodo p)
        {
            if (p != null)
            {
                preordenA += p.fact.ToString() + ",";
                preorden2(p.left);
                preorden2(p.right);
            }
        }

        public string postorden()
        {
            postordenA = "";
            if (root != null)
            {
                postorden2(root);
            }
            return postordenA;
        }

        private void postorden2(Nodo p)
        {
            if (p != null)
            {
                postorden2(p.left);
                postorden2(p.right);
                postordenA += p.fact.ToString() + ",";
            }
        }

        #endregion
    }

}

