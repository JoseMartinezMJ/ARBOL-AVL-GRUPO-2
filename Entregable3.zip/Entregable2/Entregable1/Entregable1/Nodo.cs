﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entregable2
{
    public class Nodo
    {
        #region Propiedades

        public int fact { get; set; }
        public Nodo left { get; set; }
        public Nodo right { get; set; }
        public Nodo father { get; set; }
        public Nodo() { }

        #endregion

        #region Contructores
        public Nodo(int dato, Nodo l, Nodo r, Nodo f)
        {
            this.fact = dato;
            this.left = l;
            this.right = r;
            this.father = f;
        }

        #endregion

        #region Metodo de insertar
        public Nodo insertar(int f, Nodo b)
        {
            if (b == null)
            {
                b = new Nodo(f, null, null, null);
            }
            else if (f < b.fact)
            {
                b.left = insertar(f, b.left);
            }
            else if (f > b.fact)
            {
                b.right = insertar(f, b.right);
            }
            return b;
        }

        #endregion
    }
}
