﻿
using var game = new Entregable2.Game1();
game.Run();
