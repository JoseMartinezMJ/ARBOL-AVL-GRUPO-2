﻿using Entregable2;
using Npgsql;
using System;

namespace Entregable1
{
    public class Conexion
    {
        NpgsqlConnection conn = new NpgsqlConnection("Server = localhost; User Id = postgres; Password = Jamj.2003; Database = ARBOL_AVL_DATABASE");
        public void Conectar()
        {
            conn.Open();
        }

        //COMANDOS SQL PARA EJECUTAR EN EL QUERY
        string DO = "DO $$\n";
        string BEGIN = "BEGIN\n";
        string IF = "IF EXISTS (SELECT \"CLAVE\" FROM \"ARBOL_AVL\" WHERE \"CLAVE\" = ";
        string THEN = "THEN\n";
        string Raise_Notice = "Raise Notice \'CLAVE EXISTENTE\';\n";
        string ELSE = "ELSE\n";
        string and_if = "end if; \n";
        string end = "end $$";
        //FUNCION PARA INSERTAR LAS CLAVES A LA BASE DE DATOS
        public void InsertarBasedatos(int clave)
        {
            string query = DO + BEGIN + IF + clave+")  " + THEN + Raise_Notice + ELSE + "INSERT INTO \"ARBOL_AVL\" VALUES (" + clave + ");\n"+and_if + end; 
            NpgsqlCommand Mensaje = new NpgsqlCommand(query, conn);
            Conectar();
            Mensaje.ExecuteNonQuery();
            Console.WriteLine("Clave insertada en la base de datos");
            conn.Close();
        }
        

        
    }
}
