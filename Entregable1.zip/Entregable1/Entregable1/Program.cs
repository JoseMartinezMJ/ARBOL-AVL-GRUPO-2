﻿
using var game = new Entregable1.Game1();
game.Run();
