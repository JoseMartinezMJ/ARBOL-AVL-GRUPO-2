﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//using System.Windows.Forms;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Entregable1
{
    internal class DibujarAVL
    {
        #region Propiedades

        public ArbolAVL Raiz;
        public ArbolAVL aux;

        #endregion

        #region Constructores

        public DibujarAVL()
        {
            aux = new ArbolAVL(); 
        }

        public DibujarAVL(ArbolAVL RaizNueva)
        {
            Raiz = RaizNueva;
        }

        #endregion

        #region Metodos

        //Agregar nuevo valor al arbol
        public void Insertar(int dato)
        {
            if (Raiz == null)
                Raiz = new ArbolAVL(dato, null, null, null);
            else
                Raiz = Raiz.Insertar(dato, Raiz);
        }

        //Dibuja el arbol
        public void DibujarArbol(GraphicsDeviceManager gra, SpriteBatch sprite, int dato, SpriteFont font)
        {
            int x = 300;
            int y = 100;
            if (Raiz == null) return;
            //Posicion de todos los Nodos
            Raiz.PosicionNodo(ref x, y);
            //Dibuja los Enlaces entre nodos
            Raiz.DibujarRamas(gra, sprite);
            //Dibuja todos los nodos
            Raiz.DibujarNodo(gra, sprite, dato, font);
        }

        #endregion
    }
}
