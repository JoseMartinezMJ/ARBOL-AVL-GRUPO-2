﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Entregable2
{
    internal class DibujarAVL
    {
        #region Propiedades

        public ArbolAVL Raiz;
        public ArbolAVL aux;
        private string cadena;

        #endregion

        #region Constructores

        public DibujarAVL()
        {
            aux = new ArbolAVL(); 
        }

        public DibujarAVL(ArbolAVL RaizNueva)
        {
            Raiz = RaizNueva;
        }

        #endregion

        #region Metodos

        //Agregar nuevo valor al arbol
        public void Insertar(int dato)
        {
            if (Raiz == null)
                Raiz = new ArbolAVL(dato, null, null, null);
            else
                Raiz = Raiz.Insertar(dato, Raiz);
        }


        //Dibuja el arbol
        public void DibujarArbol(GraphicsDeviceManager gra, SpriteBatch sprite, int dato, SpriteFont font)
        {
            int x = 300;
            int y = 100;
            if (Raiz == null) return;
            //Posicion de todos los Nodos
            Raiz.PosicionNodo(ref x, y);
            //Dibuja los Enlaces entre nodos
            Raiz.DibujarRamas(gra, sprite);
            //Dibuja todos los nodos
            Raiz.DibujarNodo(gra, sprite, dato, font);
        }

        public void DibujarBusqueda(GraphicsDeviceManager gra, SpriteBatch sprite, SpriteFont font, int busq, ArbolAVL ra)
        {
            Raiz.Buscar(gra, sprite, font, busq, ra);
        }

        #endregion

        #region Recorridos

        public string order(int d) //Menu de recorridos
        {
            string tem = "";
            if (d == 2)
            {
                tem = inorden();
            }
            else if (d == 3)
            {
                tem = preorden();
            }
            else if (d == 4)
            {
                tem = postorden();
            }

            return tem;
        }

        public string inorden()
        {
            cadena = "";
            if (Raiz != null)
            {
                inorden2(Raiz);
            }

            return cadena;
        }

        private void inorden2(ArbolAVL a)
        {
            if (a != null)
            {
                inorden2(a.nodoIzquierdo);
                cadena += a.Clave.ToString() + "\n";
                inorden2(a.nodoDerecho);
            }
        }

        public string preorden()
        {
            cadena = "";
            if (Raiz != null)
            {
                preorden2(Raiz);
            }
            return cadena;
        }

        private void preorden2(ArbolAVL a)
        {
            if (a != null)
            {
                cadena += a.Clave.ToString() + "\n";
                preorden2(a.nodoIzquierdo);
                preorden2(a.nodoDerecho);
            }
        }

        public string postorden()
        {
            cadena = "";
            if (Raiz != null)
            {
                postorden2(Raiz);
            }
            return cadena;
        }

        private void postorden2(ArbolAVL a)
        {
            if (a != null)
            {
                postorden2(a.nodoIzquierdo);
                postorden2(a.nodoDerecho);
                cadena += a.Clave.ToString() + "\n";
            }
        }

        #endregion
    }
}
