﻿using Npgsql;
using System;

namespace Entregable1
{
    public class Conexion
    {
        NpgsqlConnection conn = new NpgsqlConnection("Server = localhost; User Id = postgres; Password = Jamj.2003; Database = postgres");
        public void Conectar()
        {
            conn.Open();
            Console.WriteLine("Listo");
        }
        public void InsertarBasedatos(int clave)
        {
            string query = "INSERT INTO \"ARBOL_AVL\" VALUES (" + clave + ")";
            NpgsqlCommand Mensaje = new NpgsqlCommand(query, conn);
            Mensaje.ExecuteNonQuery();
            Console.WriteLine("Clave insertada en la base de datos");
            conn.Close();
        }
    }
}
