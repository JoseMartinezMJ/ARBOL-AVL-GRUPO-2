﻿
using var game = new Tarea2_EntregableFinal.Game1();
game.Run();
