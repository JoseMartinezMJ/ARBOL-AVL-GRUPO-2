﻿using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;
using System;


namespace Tarea2_EntregableFinal
{
    internal class Nodo
    {
        #region Propiedades

        public int Clave; //Almacena clave principal aleatoria
        public int Altura; //Almanacena altura del arbol

        //Nodos
        public Nodo nodoPadre; //Objeto que almacena el nodo padre
        public Nodo nodoIzquierdo; //Objeto que almacena el nodo hijo izquierdo
        public Nodo nodoDerecho; //Obejto que almacena el nodo hijo derecho

        //Posiciones
        private const int Radio = 30; //Tamanio del circulo
        private const int DistanciaH = 140; //Distancia horizontal
        private const int DistanciaV = 70; //Distancia vertical
        private int CoordenadaX; //Posicion en x
        private int CoordenadaY; //Posicion en y

        #endregion

        #region Constructores
        public Nodo()
        {

        }

        public Nodo(int claveNueva, Nodo izquierdo, Nodo derecho, Nodo padre)
        {
            Clave = claveNueva;
            Altura = 0;

            nodoPadre = padre;
            nodoDerecho = derecho;
            nodoIzquierdo = izquierdo;
        }

        #endregion

        #region Metodos de rotacion, altura y valor maximo

        //Rotacion Izquierda Simple
        private static Nodo RotacionIzquierdaSimple(Nodo k2)
        {
            Nodo k1 = k2.nodoIzquierdo;
            k2.nodoIzquierdo = k1.nodoDerecho;
            k1.nodoDerecho = k2;
            k2.Altura = max(Alturas(k2.nodoIzquierdo), Alturas(k2.nodoDerecho)) + 1;
            k1.Altura = max(Alturas(k1.nodoIzquierdo), k2.Altura) + 1;
            return k1;
        }

        //Rotacion Derecha Simple
        private static Nodo RotacionDerechaSimple(Nodo k1)
        {
            Nodo k2 = k1.nodoDerecho;
            k1.nodoDerecho = k2.nodoIzquierdo;
            k2.nodoIzquierdo = k1;
            k1.Altura = max(Alturas(k1.nodoIzquierdo), Alturas(k1.nodoDerecho)) + 1;
            k2.Altura = max(Alturas(k2.nodoDerecho), k1.Altura) + 1;
            return k2;
        }

        //Doble Rotacion Izquierda
        private static Nodo RotacionIzquierdaDoble(Nodo k3)
        {
            k3.nodoIzquierdo = RotacionDerechaSimple(k3.nodoIzquierdo);
            return RotacionIzquierdaSimple(k3);
        }

        //Doble Rotacion Derecha
        private static Nodo RotacionDerechaDoble(Nodo k1)
        {
            k1.nodoDerecho = RotacionIzquierdaSimple(k1.nodoDerecho);
            return RotacionDerechaSimple(k1);
        }


        //Valor max
        private static int max(int lhs, int rhs)
        {
            return lhs > rhs ? lhs : rhs;
        }

        //Altura
        private static int Alturas(Nodo Raiz)
        {
            return Raiz == null ? -1 : Raiz.Altura;
        }

        #endregion //MODIFICACION 11/7/2022 - Antonio

        #region Metodo de insercion de claves aleatorias, busqueda
        public Nodo Insertar(int ClaveNueva, Nodo Raiz)
        {
            if (Raiz == null)
            {
                //Crea un nuevo nodo o un espacio de memoria cada vez que se utiliza la funcion de insertar:
                Raiz = new Nodo(ClaveNueva, null, null, null);
            }
            else if (ClaveNueva < Raiz.Clave)
            {
                //Crea o inserta un nodo a la izquierda:
                Raiz.nodoIzquierdo = Insertar(ClaveNueva, Raiz.nodoIzquierdo);
            }
            else if (ClaveNueva > Raiz.Clave)
            {
                //Crea o inserta un nodo a la derecha:
                Raiz.nodoDerecho = Insertar(ClaveNueva, Raiz.nodoDerecho);
            }
            else
            {
                Console.WriteLine("Valor Existente en el Arbol");
            }


            //Realiza las rotaciones segun el caso:
            if (Alturas(Raiz.nodoIzquierdo) - Alturas(Raiz.nodoDerecho) == 2)
            {
                if (ClaveNueva < Raiz.nodoIzquierdo.Clave)
                    Raiz = RotacionIzquierdaSimple(Raiz);
                else
                    Raiz = RotacionIzquierdaDoble(Raiz);
            }
            if (Alturas(Raiz.nodoDerecho) - Alturas(Raiz.nodoIzquierdo) == 2)
            {
                if (ClaveNueva > Raiz.nodoDerecho.Clave)
                    Raiz = RotacionDerechaSimple(Raiz);
                else
                    Raiz = RotacionDerechaDoble(Raiz);
            }
            Raiz.Altura = max(Alturas(Raiz.nodoIzquierdo), Alturas(Raiz.nodoDerecho)) + 1;
            return Raiz;

        }


        #endregion //Falta terminar la funcion 11/6/2022 - Antonio

        #region Dibujo del arbol
        public void PosicionNodo(ref int xmin, int ymin)
        { //Encuentra posicion de creacion del nodo
            int aux1, aux2;

            CoordenadaY = (int)(ymin + Radio / 2);

            //obtiene la posición del Sub-Árbol izquierdo.
            if (nodoIzquierdo != null)
            {
                nodoIzquierdo.PosicionNodo(ref xmin, ymin + Radio + DistanciaV);
            }
            if ((nodoIzquierdo != null) && (nodoDerecho != null))
            {
                xmin += DistanciaH;
            }

            //Si existe el nodo derecho e izquierdo deja un espacio entre ellos.
            if (nodoDerecho != null)
            {
                nodoDerecho.PosicionNodo(ref xmin, ymin + Radio + DistanciaV);
            }

            // Posicion de nodos dercho e izquierdo.
            if (nodoIzquierdo != null)
            {
                if (nodoDerecho != null)
                {
                    //Centro entre los nodos.
                    CoordenadaX = (int)((nodoIzquierdo.CoordenadaX + nodoDerecho.CoordenadaX) / 2);
                }
                else
                {
                    //Si no hay nodo derecho, centrar al nodo izquierdo.
                    aux1 = nodoIzquierdo.CoordenadaX;
                    nodoIzquierdo.CoordenadaX = CoordenadaX - 40;
                    CoordenadaX = aux1;
                }
            }
            else if (nodoDerecho != null)
            {
                aux2 = nodoDerecho.CoordenadaX;
                //Si no hay nodo izquierdo, centrar al nodo derecho.
                nodoDerecho.CoordenadaX = CoordenadaX + 40;
                CoordenadaX = aux2;
            }
            else
            {
                //Nodo hoja
                CoordenadaX = (int)(xmin + Radio / 2);
                xmin += Radio;
            }
        }

        public void DibujarRamas(GraphicsDeviceManager grafo, SpriteBatch sprite)
        { //Dibuja las ramas de los nodos izquierdo y derecho

            if (nodoIzquierdo != null)
            {
                //arco
                MonoGame.Primitives2D.DrawLine(sprite, new Vector2(CoordenadaX, CoordenadaY), new Vector2(nodoIzquierdo.CoordenadaX, nodoIzquierdo.CoordenadaY), Color.Black, 2);
                nodoIzquierdo.DibujarRamas(grafo, sprite);
            }
            if (nodoDerecho != null)
            {   //arco
                MonoGame.Primitives2D.DrawLine(sprite, new Vector2(CoordenadaX, CoordenadaY), new Vector2(nodoDerecho.CoordenadaX, nodoDerecho.CoordenadaY), Color.Black, 2);
                nodoDerecho.DibujarRamas(grafo, sprite);
            }
        }

        public void DibujarNodo(GraphicsDeviceManager grafo, SpriteBatch sprite, int dato, SpriteFont font)
        {
            //Dibuja el contorno del nodo
            Rectangle rect = new Rectangle(
            (int)(CoordenadaX - Radio / 2),
            (int)(CoordenadaY - Radio / 2),
            Radio, Radio);
            if (Clave == dato)
            {
                MonoGame.Primitives2D.DrawCircle(sprite, new Vector2((int)(CoordenadaX - Radio / 2), (int)(CoordenadaY - Radio / 2)), Radio + 2, 40, Color.Pink, 5);

                for (int i = 0; i < 40; i++)
                {
                    MonoGame.Primitives2D.DrawCircle(sprite, new Vector2((int)((CoordenadaX) - Radio / 2), (int)((CoordenadaY) - Radio / 2)), Radio - i, 40, Color.LightPink, 5);
                }
            }
            else
            {
                MonoGame.Primitives2D.DrawCircle(sprite, new Vector2((int)(CoordenadaX - Radio / 2), (int)(CoordenadaY - Radio / 2)), Radio + 2, 40, Color.Pink, 5);

                for (int i = 0; i < 40; i++)
                {
                    MonoGame.Primitives2D.DrawCircle(sprite, new Vector2((int)((CoordenadaX) - Radio / 2), (int)((CoordenadaY) - Radio / 2)), Radio - i, 40, Color.LightPink, 5);
                }

            }
            //Letra
            sprite.DrawString(font, Clave.ToString(), new Vector2((int)(CoordenadaX - Radio / 1.5), (int)(CoordenadaY - Radio / 1.2)), Color.Black);
            //Dibuja los nodos hijos derecho e izquierdo
            if (nodoIzquierdo != null)
            {
                nodoIzquierdo.DibujarNodo(grafo, sprite, dato, font);

            }
            if (nodoDerecho != null)
            {
                nodoDerecho.DibujarNodo(grafo, sprite, dato, font);

            }



        }

        public void Buscar(GraphicsDeviceManager grafo, SpriteBatch sprite, SpriteFont font, int busqueda, Nodo Raiz)
        {

            if (Clave == busqueda)
            {
                MonoGame.Primitives2D.DrawCircle(sprite, new Vector2((int)(CoordenadaX - Radio / 2), (int)(CoordenadaY - Radio / 2)), Radio + 2, 40, Color.Blue, 5);

                for (int i = 0; i < 40; i++)
                {
                    MonoGame.Primitives2D.DrawCircle(sprite, new Vector2((int)((CoordenadaX) - Radio / 2), (int)((CoordenadaY) - Radio / 2)), Radio - i, 40, Color.LightBlue, 5);
                }
            }
            sprite.DrawString(font, Clave.ToString(), new Vector2((int)(CoordenadaX - Radio / 1.5), (int)(CoordenadaY - Radio / 1.2)), Color.Black);
            if (nodoIzquierdo != null)
            {
                nodoIzquierdo.Buscar(grafo, sprite, font, busqueda, Raiz);

            }
            if (nodoDerecho != null)
            {
                nodoDerecho.Buscar(grafo, sprite, font, busqueda, Raiz);

            }
        }

        #endregion
    }
}
