﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Linq;
using Tarea2_EntregableFinal.Boton_Textbox;

namespace Tarea2_EntregableFinal
{
    public class Game1 : Game
    {
        #region Propiedades 

        private GraphicsDeviceManager _graphics;
        private SpriteBatch _spriteBatch;
        private SpriteFont _spriteFont;

        private TextBox _numericTextBox; //Caja de texto
        private Vector2 _numericTextBoxPosition;  //Posicion caja de texto

        private KeyboardState _oneShotKeyboardState; //Controlar eventos de teclado
        private MouseState _oneShotMouseState; //Controlar eventos del mouse
        private int _timeBeforeNextDelete; //Controlar si se borran numeros del textbox
        private int _length; //Laro textbox

        AVL arbolAVL = new AVL(null); //Arbol

        public static int ScreenWidth = 1280; //Pantalla Ancho
        public static int ScreenHeight = 720; //Pantalla Alto

        private Color _backgroundColour = Color.DarkGray; //Fondo
        private List<Component> _gameComponents; //Para cargar los botones
        int pintaR = 0; //Para controlar el evento de los botones
        Conexion conexion = new Conexion();



        #endregion


        public Game1()
        {
            _graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            IsMouseVisible = true;
            Window.IsBorderless = true;
        }
        //FINAL
        protected override void Initialize()
        {
            _graphics.PreferredBackBufferWidth = ScreenWidth;
            _graphics.PreferredBackBufferHeight = ScreenHeight;


            _numericTextBoxPosition = new Vector2(40, 120);
            _length = 10;
            _timeBeforeNextDelete = 10;
            _graphics.ApplyChanges();



            base.Initialize();
        }

        protected override void LoadContent()
        {
            _spriteBatch = new SpriteBatch(GraphicsDevice);
            _spriteFont = Content.Load<SpriteFont>("Font");

            //Crear textbox
            _numericTextBox = new TextBox(Content.Load<Texture2D>("Button"), Content.Load<Texture2D>("computer-mouse"), new Point(122, 24), new Point(2, 12), _numericTextBoxPosition, _length, true, true, Content.Load<SpriteFont>("File"), String.Empty, 0.9f);

            #region Crear Botones

            var btnInsertar = new Button(Content.Load<Texture2D>("Button"), Content.Load<SpriteFont>("File"))
            {
                Position = new Vector2(40, 40),
                Text = "Insertar"
            };

            btnInsertar.Click += btnInsertarClick;


            var btnBuscar = new Button(Content.Load<Texture2D>("Button"), Content.Load<SpriteFont>("File"))
            {
                Position = new Vector2(40, 80),
                Text = "Buscar"
            };

            btnBuscar.Click += btnBuscarClick;


            var btnInorden = new Button(Content.Load<Texture2D>("Button"), Content.Load<SpriteFont>("File"))
            {
                Position = new Vector2(40, 160),
                Text = "InOrden"
            };

            btnInorden.Click += btnInordenClick;


            var btnPreOrden = new Button(Content.Load<Texture2D>("Button"), Content.Load<SpriteFont>("File"))
            {
                Position = new Vector2(40, 200),
                Text = "PreOrden"
            };

            btnPreOrden.Click += btnPreOrdenClick;


            var btnPostOrden = new Button(Content.Load<Texture2D>("Button"), Content.Load<SpriteFont>("File"))
            {
                Position = new Vector2(40, 240),
                Text = "PostOrden"
            };

            btnPostOrden.Click += btnPostOrdenClick;

            #endregion


            //Listar botones
            _gameComponents = new List<Component>()
                {
                    btnInsertar,
                    btnBuscar,
                    btnInorden,
                    btnPreOrden,
                    btnPostOrden,

                };

        }

        #region Eventos al presionar botones

        //Aqui va el codigo para que inserte un nuevo valor aleatorio, para --> Antonio
        private void btnInsertarClick(object sender, System.EventArgs e)
        {
            var seed = Environment.TickCount;
            var random = new Random(seed);
            var value = random.Next(1, 11);
            arbolAVL.Insertar(value);
            pintaR = 0;

        }

        private void btnBuscarClick(object sender, System.EventArgs e)
        {
            //Al precionar el boton, pintaR pasa a valer 1, que permite a el metodo draw buscar el nodo que este en el textbox en ese momento.
            pintaR = 1;
        }

        //Aqui va el codigo para que muestre el orden PreOrden, para --> Alex
        private void btnPreOrdenClick(object sender, System.EventArgs e)
        {
            pintaR = 3;
        }

        //Aqui va el codigo para que muestre el orden InOrden, para --> Alisson
        private void btnInordenClick(object sender, System.EventArgs e)
        {
            pintaR = 2;

        }

        //Aqui va el codigo para que muestre el orden PostOrden, para --> Alisson
        private void btnPostOrdenClick(object sender, System.EventArgs e)
        {
            pintaR = 4;
        }

        #endregion


        protected override void Update(GameTime gameTime)
        {
            //Toman los estados del teclado y mouse
            _oneShotKeyboardState = OneShotKeyboard.GetState();
            _oneShotMouseState = OneShotMouseButton.GetState();

            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
            {
                conexion.EliminarAlCerrar();
                Exit();

            }

            foreach (var component in _gameComponents)
                component.Update(gameTime);

            HandleInput(gameTime);
            _numericTextBox.Update();

            base.Update(gameTime);
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(_backgroundColour);

            _spriteBatch.Begin();

            arbolAVL.DibujarArbol(_graphics, _spriteBatch, 20, _spriteFont); //Dibuja el arbol
            _numericTextBox.Render(_spriteBatch); //Dibuja el textbox

            if (pintaR == 1) //Dibuja el boton BUSQUEDA
            {
                if (_numericTextBox.CurrentText != "") //Si no hay valores en el textbox
                {
                    arbolAVL.DibujarBusqueda(_graphics, _spriteBatch, _spriteFont, int.Parse(_numericTextBox.CurrentText), arbolAVL.Raiz); //Dibuja el elemento buscado
                    int prueba = int.Parse(_numericTextBox.CurrentText); //Toma ese ultimo elemento buscado
                    if (prueba != int.Parse(_numericTextBox.CurrentText)) //Comparamos el ultimo buscado con cualquier otro cambio que se haga en el textbox
                    {
                        pintaR = 0; //Si el valor cambia, deja de dibujar, solo volvera a dibujar al precionar buscar otra vez.
                    }
                }
            }
            else if (pintaR == 2) //Dibuja el boton INORDEN
            {
                _spriteBatch.DrawString(_spriteFont, "INORDEN: \n" + arbolAVL.order(2), new Vector2(40, 300), Color.Black);
            }
            else if (pintaR == 3) //Dibuja el boton PREORDEN
            {
                _spriteBatch.DrawString(_spriteFont, "PREORDEN: \n" + arbolAVL.order(3), new Vector2(40, 300), Color.Black);
            }
            else if (pintaR == 4) //Dibuja el boton POSTORDEN
            {
                _spriteBatch.DrawString(_spriteFont, "POSTORDEN: \n" + arbolAVL.order(4), new Vector2(40, 300), Color.Black);
            }

            foreach (var component in _gameComponents)
                component.Draw(gameTime, _spriteBatch); //Dibuja los botones


            _spriteBatch.End();


            base.Draw(gameTime);
        }

        #region Metodos para el textbox
        protected void HandleInput(GameTime gameTime)
        {
            Keys[] keys = _oneShotKeyboardState.GetPressedKeys();
            string value = String.Empty;

            if (_oneShotMouseState.LeftButton == ButtonState.Pressed)
            {
                if (OneShotMouseButton.HasNotBeenPressed(true))
                {
                    HandleLeftMouseButtonClick();
                }
            }

            if (_oneShotKeyboardState.IsKeyUp(Keys.Back) && _oneShotKeyboardState.IsKeyUp(Keys.Delete))
                _timeBeforeNextDelete = 10;

            if (keys.Count() > 0)
            {
                if (keys.Count() > 1)
                    keys[0] = ExtractingSingleCharacterOrNumer(keys);

                if (_oneShotKeyboardState.IsKeyDown(Keys.Back) || _oneShotKeyboardState.IsKeyDown(Keys.Delete))
                {
                    if (_timeBeforeNextDelete == 0)
                    {
                        _timeBeforeNextDelete = 10;
                    }

                    if (_timeBeforeNextDelete == 10)
                    {
                        if (_numericTextBox.Selected)
                            _numericTextBox.AddMoreText('\b');

                        _timeBeforeNextDelete--;
                    }
                    else
                    {
                        _timeBeforeNextDelete--;
                    }
                    return;
                }

                if (_numericTextBox.Selected)
                {
                    if (((int)keys[0] >= 48 && (int)keys[0] <= 57) || ((int)keys[0] >= 96 && (int)keys[0] <= 105))
                    {
                        value = keys[0].ToString().Substring(keys[0].ToString().Length - 1);

                        if (OneShotKeyboard.HasNotBeenPressed(keys[0]))
                        {
                            _numericTextBox.AddMoreText(value.ToCharArray()[0]);
                        }
                    }
                }



            }

        }

        private void HandleLeftMouseButtonClick()
        {
            if (_oneShotMouseState.X >= _numericTextBox.Position.X && _oneShotMouseState.X <= _numericTextBox.Position.X + _numericTextBox.CellWidth)
            {
                if (_oneShotMouseState.Y >= _numericTextBox.Position.Y && _oneShotMouseState.Y <= _numericTextBox.Position.Y + _numericTextBox.CellHeight)
                {
                    _numericTextBox.Selected = true;
                }

            }
        }

        private Keys ExtractingSingleCharacterOrNumer(Keys[] keys)
        {
            foreach (Keys key in keys)
            {
                if ((int)key >= 48 && (int)key <= 185)
                    return key;
            }
            return Keys.None;
        }

        #endregion
    }
}