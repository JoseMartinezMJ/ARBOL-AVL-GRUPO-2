﻿using Npgsql;
using System;

namespace Tarea2_EntregableFinal
{
    internal class Conexion
    {
        //LA CONTRASENIA DEPENDE DE LA CLAVE QUE USTED HAYA ASIGNADO EN SU PGADMIN, Y TIENE QUE EDITARSE POR LA CORRECTA PARA FUNCIONAR. -----
        NpgsqlConnection conn = new NpgsqlConnection("Server = localhost; User Id = postgres; Password = Jamj.2003; Database = ARBOL_AVL_DATABASE");


        //FUNCION PARA CONECTAR Y ABRIR LA CONEXION A LA BASE DE DATOS
        public void Conectar()
        {
            conn.Open();
        }

        //COMANDOS SQL PARA EJECUTAR EN EL QUERY
        string DO = "DO $$\n";
        string BEGIN = "BEGIN\n";
        string IF = "IF EXISTS (SELECT \"CLAVE\" FROM \"ARBOL_AVL\" WHERE \"CLAVE\" = ";
        string THEN = "THEN\n";
        string Raise_Notice = "Raise Notice \'CLAVE EXISTENTE\';\n";
        string ELSE = "ELSE\n";
        string and_if = "end if; \n";
        string end = "end $$";
        //FUNCION PARA INSERTAR LAS CLAVES A LA BASE DE DATOS
        public void InsertarBasedatos(int clave)
        {
            string query = DO + BEGIN + IF + clave + ")  " + THEN + Raise_Notice + ELSE + "INSERT INTO \"ARBOL_AVL\" VALUES (" + clave + ");\n" + and_if + end;
            NpgsqlCommand Mensaje = new NpgsqlCommand(query, conn);
            Conectar();
            Mensaje.ExecuteNonQuery();
            Console.WriteLine("Clave insertada en la base de datos");
            conn.Close();
        }

        //FUNCION PARA EKIMNAR TODAS LAS CLAVES AL CERRAR EL PROGRAMA
        public void EliminarAlCerrar()
        {
            string consulta = "DELETE FROM \"ARBOL_AVL\"";
            NpgsqlCommand Mensaje = new NpgsqlCommand(consulta, conn);
            Conectar();
            Mensaje.ExecuteNonQuery();
            Console.WriteLine("Claves eliminadas de la base de datos");
            conn.Close();
        }

    }
}
